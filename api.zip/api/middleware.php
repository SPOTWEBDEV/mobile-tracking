<?php
require "./helpers/jwt.php";


$headers = getallheaders();

if (!isset($headers['Authorization'])) {
    echo json_encode([
        "status" => false,
        "message" => "No token provided"
    ]);
    exit;
}

$token = str_replace("Bearer ", "", $headers['Authorization']);

$decoded = verifyJWT($token, $secret);

if (!$decoded) {
    echo json_encode([
        "status" => false,
        "message" => "Invalid or expired token"
    ]);
    exit;
}

// ✅ available globally
$user_id = $decoded['user_id'];