<?php
$host = "localhost";
$user = "spotweb1_monitor-spirit";
$pass = "spotweb1_monitor-spirit";
$db   = "spotweb1_monitor-spirit";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$secret = "my_super_secret_key_123";
?>