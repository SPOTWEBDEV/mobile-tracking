<?php
include("./config/db.php");
require "./middleware.php"; // gives you $user_id

header("Content-Type: application/json");

// get input
$data = json_decode(file_get_contents("php://input"), true);
$code = trim($data['code'] ?? '');

if (!$code) {
    echo json_encode([
        "status" => false,
        "message" => "Code is required"
    ]);
    exit;
}

/**
 * 1️⃣ FIND VALID CODE
 */
$stmt = $conn->prepare("
    SELECT device_id, expires_at 
    FROM link_codes 
    WHERE code=? 
    LIMIT 1
");
$stmt->bind_param("s", $code);
$stmt->execute();

$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    echo json_encode([
        "status" => false,
        "message" => "Invalid code"
    ]);
    exit;
}

/**
 * 2️⃣ CHECK EXPIRATION
 */
if (strtotime($row['expires_at']) < time()) {
    echo json_encode([
        "status" => false,
        "message" => "Code expired"
    ]);
    exit;
}

$device_id = $row['device_id'];

/**
 * 3️⃣ GET DEVICE OWNER (IMPORTANT)
 */
$ownerStmt = $conn->prepare("
    SELECT user_id 
    FROM devices 
    WHERE device_id=? 
    LIMIT 1
");
$ownerStmt->bind_param("s", $device_id);
$ownerStmt->execute();

$ownerResult = $ownerStmt->get_result();
$owner = $ownerResult->fetch_assoc();

if (!$owner) {
    echo json_encode([
        "status" => false,
        "message" => "Device not found"
    ]);
    exit;
}

/**
 * ❌ 4️⃣ BLOCK SELF LINK
 */
if ((int)$owner['user_id'] === (int)$user_id) {
    echo json_encode([
        "status" => false,
        "message" => "You cannot link your own device"
    ]);
    exit;
}

/**
 * ❌ 5️⃣ PREVENT DUPLICATE LINK
 */
$check = $conn->prepare("
    SELECT id 
    FROM device_links 
    WHERE user_id=? AND device_id=?
");
$check->bind_param("is", $user_id, $device_id);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo json_encode([
        "status" => false,
        "message" => "Device already linked"
    ]);
    exit;
}

/**
 * 6️⃣ INSERT LINK
 */
$insert = $conn->prepare("
    INSERT INTO device_links (user_id, device_id)
    VALUES (?, ?)
");
$insert->bind_param("is", $user_id, $device_id);

if (!$insert->execute()) {
    echo json_encode([
        "status" => false,
        "message" => "Failed to link device"
    ]);
    exit;
}

/**
 * 🔥 7️⃣ DELETE USED CODE (IMPORTANT)
 */
$delete = $conn->prepare("DELETE FROM link_codes WHERE code=?");
$delete->bind_param("s", $code);
$delete->execute();

/**
 * ✅ SUCCESS
 */
echo json_encode([
    "status" => true,
    "message" => "Device linked successfully"
]);