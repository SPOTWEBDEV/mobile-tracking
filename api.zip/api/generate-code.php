<?php
include("./config/db.php");
require "./middleware.php";
$data = json_decode(file_get_contents("php://input"), true);
$device_id = $data['device_id'] ?? '';

if (!$device_id) {
    echo json_encode(["status" => false, "message" => "Device ID required"]);
    exit;
}

// generate code
$code = strtoupper(substr(md5(uniqid()), 0, 6));
$expires = date("Y-m-d H:i:s", time() + 300);

// delete old codes for this device
$conn->query("DELETE FROM link_codes WHERE device_id='$device_id'");

// insert new
$stmt = $conn->prepare("
  INSERT INTO link_codes (device_id, code, expires_at)
  VALUES (?, ?, ?)
");
$stmt->bind_param("sss", $device_id, $code, $expires);
$stmt->execute();

echo json_encode([
  "status" => true,
  "code" => $code
]);