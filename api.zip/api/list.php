<?php

include("./config/db.php");
require "./middleware.php";
$stmt = $conn->prepare("
  SELECT d.device_name, d.device_id
  FROM device_links dl
  JOIN devices d ON dl.device_id = d.device_id
  WHERE dl.user_id=?
");

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
$devices = [];

while ($row = $result->fetch_assoc()) {
    $devices[] = $row;
}

echo json_encode([
  "status" => true,
  "devices" => $devices
]);