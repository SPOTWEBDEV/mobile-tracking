<?php

function base64UrlEncode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64UrlDecode($data) {
    return base64_decode(strtr($data, '-_', '+/'));
}

function createJWT(array $payload, string $secret): string {
    $header = base64UrlEncode(json_encode([
        "typ" => "JWT",
        "alg" => "HS256"
    ]));

    $payload = base64UrlEncode(json_encode($payload));

    $signature = hash_hmac(
        "sha256",
        "$header.$payload",
        $secret,
        true
    );

    return "$header.$payload." . base64UrlEncode($signature);
}

/* ======================
   VERIFY JWT
====================== */
function verifyJWT(string $token, string $secret) {
    $parts = explode('.', $token);

    if (count($parts) !== 3) {
        return false;
    }

    [$header, $payload, $signature] = $parts;

    $validSignature = base64UrlEncode(
        hash_hmac("sha256", "$header.$payload", $secret, true)
    );

    if (!hash_equals($validSignature, $signature)) {
        return false;
    }

    $decodedPayload = json_decode(base64UrlDecode($payload), true);

    // Expiration check
    if (isset($decodedPayload['exp']) && $decodedPayload['exp'] < time()) {
        return false;
    }

    return $decodedPayload;
}
