<?php
include("./config/db.php");

header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$username = $data['username'] ?? '';
$email = $data['email'] ?? '';
$password = $data['password'] ?? '';
$device_id = $data['device_id'] ?? '';
$device_name = $data['device_name'] ?? 'Unknown Device';
$plan = $data['plan'] ?? 'free';

if (!$username || !$email || !$password || !$device_id) {
    echo json_encode([
        "status" => false,
        "message" => "All fields are required"
    ]);
    exit;
}

// hash password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// check email
$check = $conn->prepare("SELECT id FROM users WHERE email=?");
$check->bind_param("s", $email);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo json_encode([
        "status" => false,
        "message" => "Email already exists"
    ]);
    exit;
}

/**
 * 1️⃣ CREATE USER
 */
$stmt = $conn->prepare("
    INSERT INTO users (username, email, password, plan)
    VALUES (?, ?, ?, ?)
");
$stmt->bind_param("ssss", $username, $email, $hashedPassword, $plan);

if (!$stmt->execute()) {
    echo json_encode([
        "status" => false,
        "message" => "Registration failed"
    ]);
    exit;
}

$user_id = $stmt->insert_id;

/**
 * 2️⃣ REGISTER DEVICE
 */
$deviceStmt = $conn->prepare("
    INSERT INTO devices (user_id, device_id, device_name)
    VALUES (?, ?, ?)
");
$deviceStmt->bind_param("iss", $user_id, $device_id, $device_name);
$deviceStmt->execute();

echo json_encode([
    "status" => true,
    "message" => "Account created successfully"
]);