<?php
include("./config/db.php");
require "./helpers/jwt.php";

header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);

$email = $data['email'] ?? '';
$password = $data['password'] ?? '';


if (!$email || !$password) {
    echo json_encode([
        "status" => false,
        "message" => "Email and password required"
    ]);
    exit;
}

/**
 * 1️⃣ FETCH USER
 */
$stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();

$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    echo json_encode([
        "status" => false,
        "message" => "User not found"
    ]);
    exit;
}

/**
 * 2️⃣ VERIFY PASSWORD
 */
if (!password_verify($password, $user['password'])) {
    echo json_encode([
        "status" => false,
        "message" => "Invalid password"
    ]);
    exit;
}

/**
 * 3️⃣ CHECK IF DEVICE EXISTS
 */
$deviceStmt = $conn->prepare("
    SELECT device_id, device_name 
    FROM devices 
    WHERE user_id=? LIMIT 1
");
$deviceStmt->bind_param("s", $user['id']);
$deviceStmt->execute();

$device = $deviceStmt->get_result()->fetch_assoc();

/**
 * 4️⃣ REGISTER DEVICE IF NEW
 */
if (!$device && $device_id) {
    $insertDevice = $conn->prepare("
        INSERT INTO devices (user_id, device_id, device_name)
        VALUES (?, ?, ?)
    ");
    $insertDevice->bind_param("iss", $user['id'], $device_id, $device_name);
    $insertDevice->execute();

    $device = [
        "device_id" => $device_id,
        "device_name" => $device_name
    ];
}

/**
 * 5️⃣ CREATE JWT
 */
$token = createJWT([
    "user_id" => $user['id'],
    "email" => $user['email'],
    "iat" => time(),
    "exp" => time() + (60 * 60 * 24)
], $secret);

/**
 * 6️⃣ RESPONSE
 */
echo json_encode([
    "status" => true,
    "message" => "Login successful",
    "token" => $token,
    "user" => [
        "id" => $user['id'],
        "username" => $user['username'],
        "email" => $user['email'],
        "plan" => $user['plan'],
        "device" => $device
    ]
    
]);